const colors = ['srgb', 'linear-rgb', 'oklab', 'cielab', 'oklch', 'weighted-rgb', 'weighted-rgb-601', 'weighted-rgb-709'];
const resizes = ['nearest', 'bilinear', 'area', 'lanczos2', 'lanczos2-scale-aware', 'lanczos3', 'lanczos3-scale-aware'];
const dithers = ['bayer-2', 'bayer-4', 'bayer-8', 'bayer-16', 'random', 'floyd-steinberg', 'sierra', 'sierra-lite'];
export const cases = [];
function add(id, scale, options = {}) {
  cases.push({ id, scale, width: Math.round(2600 * scale), height: Math.round(4168 * scale),
    resize: 'nearest', colorSpace: 'srgb', algorithm: 'none', ...options });
}
for (const scale of [.05, .1, .25, .5, 1, 1.5]) for (const resizeOnly of [false, true])
  add(`scale-${scale * 100}-${resizeOnly ? 'resize' : 'process'}`, scale, { resizeOnly });
for (const resize of resizes.slice(1)) for (const [scale, resizeOnly] of [[.05,true],[.25,true],[.1,false],[.5,false]])
  add(`resize-${resize}-${scale * 100}-${resizeOnly ? 'resize' : 'process'}`, scale, { resize, resizeOnly });
for (const colorSpace of colors.slice(1)) for (const scale of [.1,.5])
  add(`color-${colorSpace}-${scale * 100}`, scale, { colorSpace });
for (const algorithm of dithers) for (const scale of [.1,.5])
  add(`dither-${algorithm}-${scale * 100}`, scale, { algorithm });
for (const [i,colorSpace] of colors.entries()) {
  add(`mix-ordered-${colorSpace}`, .25, { colorSpace, resize: resizes[i % 7], algorithm: dithers[i % 4],
    vector: true, adaptive: true, strength: 25, placementRadius: 4, placementThreshold: 12, placementSoftness: 8 });
  add(`mix-diffusion-${colorSpace}`, .1, { colorSpace, algorithm: ['floyd-steinberg','sierra','sierra-lite'][i % 3],
    vector: true, adaptive: true, strength: 100, serpentine: false, placementRadius: 2,
    placementThreshold: 5, placementSoftness: 2, mixedAlpha: true,
    alphaMode: ['preserve','matte','premultiplied'][i % 3] });
  add(`mix-random-${colorSpace}`, .05, { colorSpace, algorithm: 'random', vector: true, adaptive: true, seed: 0 });
}
for (const alphaMode of ['preserve','matte','premultiplied']) add(`alpha-${alphaMode}`, .25, { alphaMode, mixedAlpha: true });
for (const [colorSpace,scale] of [['srgb',.1],['srgb',.5],['oklab',.1]]) add(`entropy-${colorSpace}-${scale * 100}`, scale, { colorSpace, entropy: true });
if (cases.length !== 96 || new Set(cases.map(c=>c.id)).size !== cases.length) throw new Error('Invalid screening matrix');
export const rounds = 3;
export const callTimeoutMs = 90_000;
