export function timerResolution() {
  let previous = performance.now();
  let minimum = Infinity;
  for (let i = 0; i < 100_000; i++) {
    const current = performance.now();
    if (current > previous) minimum = Math.min(minimum, current - previous);
    previous = current;
  }
  return Number.isFinite(minimum) ? minimum : null;
}
