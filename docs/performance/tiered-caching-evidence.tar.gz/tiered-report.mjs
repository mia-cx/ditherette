import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const directory = path.dirname(fileURLToPath(import.meta.url));
const trials = ['tiered-baseline-01', 'tiered-candidate-01'];
const reports = await Promise.all(trials.map(async trial => JSON.parse(await readFile(path.join(directory, trial, 'results.json'), 'utf8'))));
const median = values => [...values].sort((a, b) => a - b)[1];
const summary = { timedCalls: 0, untimedPrimes: 0, identicalRenderedPairs: 0, browsers: {}, artifacts: [] };
for (const report of reports) {
  assert.equal(Object.keys(report.browsers).length, 3);
  summary.artifacts.push({ revision: report.candidateRevision, wasmSha256: report.scalarWasmSha256, scripts: report.scripts });
  for (const browser of Object.values(report.browsers)) {
    assert.deepEqual(browser.errors, []);
    assert.equal(browser.results.length, 4);
    for (const result of browser.results) {
      assert.equal(result.error, undefined);
      for (const backend of Object.values(result.backends)) {
        assert.equal(backend.untimedPrimes, 3);
        summary.untimedPrimes += 3;
        for (const mode of ['uncached', 'warm', 'repeats']) {
          assert.equal(backend[mode].length, 3);
          summary.timedCalls += 3;
          for (const sample of backend[mode]) {
            assert.ok(Number.isFinite(sample.e2eMs) && sample.e2eMs >= 0);
            if (sample.stability) assert.equal(sample.stability.changedPixels, 0);
          }
        }
      }
    }
  }
}
for (const [engine, browser] of Object.entries(reports[1].browsers)) {
  summary.browsers[engine] = [];
  for (const result of browser.results) {
    const previous = reports[0].browsers[engine].results.find(row => row.id === result.id);
    assert.deepEqual(previous.recipe, result.recipe);
    assert.equal(previous.inputPixelHash, result.inputPixelHash);
    assert.deepEqual(previous.difference, result.difference);
    const row = { recipe: result.recipe, renderedSha256: {}, before: {}, after: {} };
    for (const backend of ['wasm', 'js']) {
      const images = await Promise.all(trials.map(trial => readFile(path.join(directory, trial, 'images', `${engine}-${result.id}-${backend}.png`))));
      assert.deepEqual(images[0], images[1]);
      row.renderedSha256[backend] = createHash('sha256').update(images[1]).digest('hex');
      summary.identicalRenderedPairs++;
      for (const [name, data] of [['before', previous], ['after', result]]) {
        row[name][backend] = {};
        for (const mode of ['uncached', 'warm', 'repeats']) {
          const samples = data.backends[backend][mode];
          row[name][backend][mode] = Object.fromEntries(['e2eMs', 'publicCallMs'].map(metric => [metric, {
            median: median(samples.map(sample => sample[metric])),
            min: Math.min(...samples.map(sample => sample[metric])),
            max: Math.max(...samples.map(sample => sample[metric]))
          }]));
          assert.deepEqual(samples.map(sample => sample.warnings), previous.backends[backend][mode].map(sample => sample.warnings));
        }
      }
    }
    summary.browsers[engine].push(row);
  }
}
assert.equal(summary.timedCalls, 432);
assert.equal(summary.untimedPrimes, 144);
assert.equal(summary.identicalRenderedPairs, 24);
await writeFile(path.join(directory, 'tiered-summary.json'), JSON.stringify(summary, null, 2));
console.log(JSON.stringify({ timedCalls: summary.timedCalls, untimedPrimes: summary.untimedPrimes, identicalRenderedPairs: summary.identicalRenderedPairs }));
