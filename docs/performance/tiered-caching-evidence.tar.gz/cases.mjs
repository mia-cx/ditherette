export const cases = [65, 130, 260, 390, 650, 975, 1300, 1950, 2600].map(width => ({
  id: `scale-${width}`,
  scale: width / 2600,
  width,
  height: Math.round(width * 4168 / 2600),
  resize: 'nearest',
  colorSpace: 'srgb',
  algorithm: 'none'
}));
export const rounds = 3;
export const callTimeoutMs = 90_000;
