import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import ts from 'typescript';

const base = new URL('./', import.meta.url);
const root = new URL('../../', base);
const inputs = [];
for (const [source, output] of [
  ['src/lib/palette/wplace.ts', 'palette.js'],
  ['src/lib/processing/package-adapter.ts', 'adapter.js']
]) {
  const text = await readFile(new URL(source, root), 'utf8');
  inputs.push({ source, sha256: createHash('sha256').update(text).digest('hex') });
  const result = ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } });
  await writeFile(new URL(output, base), result.outputText.replace("'./bayer'", "'/typescript/src/lib/processing/bayer.js'"));
}
await writeFile(new URL('adapter-inputs.json', base), JSON.stringify(inputs, null, 2));
