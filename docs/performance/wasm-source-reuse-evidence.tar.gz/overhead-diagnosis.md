# Public Wasm overhead diagnosis

2026-09-10. Implementation request follows the Celeste browser comparison.

## Confirmed bottleneck

The Chromium CPU profile of 12 cached public nearest resizes attributes 1,078,858 microseconds to Wasm function 15. That is about 91% of sampled time. Its disassembly contains the SHA-256 compression state, rotations, and first round constant 1116352408. Input copying accounts for 53,229 microseconds, about 4.5%; output copying accounts for 16,069 microseconds, about 1.4%.

The profile uses a temporary opt-level 3 build. It is retained in opt3-cached-resize.cpuprofile. This does not measure Firefox's internal attribution.

## Build experiment

Changing only release opt-level from s to 3 improves the four-case exploratory browser run. At 650 × 1042, Chromium nearest + sRGB drops from the earlier 416 ms median to 278 ms. The repeated request drops from 223 ms to 116 ms. Firefox remains slow. Fresh full paired selection has not run.

The experiment is unselected. The trusted freeze checker fixes the core manifest release profile to s. Cargo.toml has been restored; no freeze policy is bypassed or changed.

## Compatibility fix

prod/color/packed.rs now uses stable chunks_exact/chunks_exact_mut and copies each computed triplet. This fixes compilation under the pinned threaded Rust toolchain without changing arithmetic. The full npm package builds with both variants under the experimental profile, and the frozen-bit packed-color test passes. The standard-profile build still needs rerunning after the experiment's reversal.

## Approved implementation

Mia approved exact-byte verified source reuse on 2026-09-10. Production now retains initialized source scratch with its dimensions and SHA identity after success. The private boundary compares every current byte before reuse. A mismatch copies and hashes again. No extra source buffer or public API was added. The frozen reference stays unchanged.

Focused Rust tests cover mutation, equal byte counts with different dimensions, memory pressure, failures, and disposal. The full native suite, standard-profile scalar and threaded builds, and independent freeze guard pass. Browser checks and paired measurements follow. The opt-level experiment remains unselected.

No PR has been filed or merged for this diagnostic checkpoint.
