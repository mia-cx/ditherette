const recipes = [];
function add(id, width, resize = 'nearest', colorSpace = 'srgb', algorithm = 'none', extra = {}) {
  recipes.push({ id, width, height: Math.round(width * 4168 / 2600), resize, colorSpace, algorithm, ...extra });
}
for (const width of [260, 650, 1300, 2600]) add(`scale-${width}`, width);
for (const resize of ['area', 'bilinear', 'lanczos2', 'lanczos3', 'lanczos3-scale-aware']) add(`filter-${resize}`, 650, resize);
for (const space of ['linear-rgb', 'oklab', 'cielab', 'oklch', 'weighted-rgb-709']) add(`space-${space}`, 650, 'nearest', space);
for (const algo of ['bayer-2', 'bayer-8', 'random', 'floyd-steinberg', 'sierra', 'sierra-lite']) add(`dither-${algo}`, 650, 'nearest', 'srgb', algo);
add('oklab-floyd-matching', 650, 'nearest', 'oklab', 'floyd-steinberg', { vector: true });
add('oklab-bayer-adaptive', 260, 'area', 'oklab', 'bayer-8', { vector: true, adaptive: true });
add('resize-only-nearest', 650, 'nearest', 'srgb', 'none', { resizeOnly: true });
add('resize-only-lanczos3', 650, 'lanczos3', 'srgb', 'none', { resizeOnly: true });
add('new-trilinear', 650, 'nearest', 'srgb', 'none', { wasmOnly: true, resizeOverride: { algorithm: 'trilinear', anchor: 'center' } });
add('new-atkinson', 650, 'nearest', 'srgb', 'none', { wasmOnly: true, ditherOverride: { family: 'diffusion', kernel: 'atkinson', feedback: 'srgb-bytes', strength: 0.75, serpentine: true, placement: { mode: 'everywhere' } } });
add('new-ciede2000', 260, 'nearest', 'srgb', 'none', { wasmOnly: true, matchingOverride: 'cielab-ciede2000' });
add('new-yliluoma-adaptive', 130, 'nearest', 'srgb', 'none', { wasmOnly: true, ditherOverride: { family: 'yliluoma', size: '4', placement: { mode: 'adaptive', radius: 1, threshold: 0.1, softness: 0.1 } } });
export const cases = recipes;
export const rounds = 3;
export const callTimeoutMs = 90_000;
