import { rounds, callTimeoutMs } from './cases.mjs';
const canvas = document.querySelector('canvas');
let source;
window.loadSource = async () => {
  const start = performance.now();
  const bytes = await (await fetch('/celeste.png')).blob();
  const fetched = performance.now();
  const bitmap = await createImageBitmap(bytes);
  const temporary = new OffscreenCanvas(bitmap.width, bitmap.height);
  const context = temporary.getContext('2d', { willReadFrequently: true });
  context.drawImage(bitmap, 0, 0);
  source = context.getImageData(0, 0, bitmap.width, bitmap.height);
  bitmap.close();
  const decoded = performance.now();
  const pixelHash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', source.data))].map(x => x.toString(16).padStart(2, '0')).join('');
  return { width: source.width, height: source.height, fetchMs: fetched - start,
    decodeReadbackMs: decoded - fetched, pixelHash, userAgent: navigator.userAgent, hardwareConcurrency: navigator.hardwareConcurrency };
};
function rpc(worker, message, transfer = []) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => { worker.terminate(); reject(new Error(`Worker call exceeds ${callTimeoutMs} ms`)); }, callTimeoutMs);
    worker.onmessage = ({ data }) => {
      clearTimeout(timeout);
      data.error ? reject(new Error(data.error)) : resolve(data);
    };
    worker.onerror = e => { clearTimeout(timeout); reject(new Error(e.message)); };
    worker.postMessage(message, transfer);
  });
}
function expand(response, recipe) {
  const input = new Uint8Array(response.buffer);
  if (recipe.resizeOnly) return new Uint8ClampedArray(input.buffer);
  const rgba = new Uint8ClampedArray(recipe.width * recipe.height * 4);
  if (input.length !== recipe.width * recipe.height) throw new Error('Wrong output length');
  for (let i = 0; i < input.length; i++) {
    const p = input[i] * 4;
    if (p + 3 >= response.palette.length) throw new Error('Invalid palette index');
    for (let ch = 0; ch < 4; ch++) rgba[i * 4 + ch] = response.palette[p + ch];
  }
  return rgba;
}
function difference(a, b) {
  if (a.length !== b.length) throw new Error('Output size mismatch');
  let changedPixels = 0, sum = 0, squared = 0, max = 0;
  for (let i = 0; i < a.length; i += 4) {
    let changed = false;
    for (let ch = 0; ch < 4; ch++) {
      const delta = Math.abs(a[i + ch] - b[i + ch]);
      changed ||= delta !== 0;
      if (ch < 3) { sum += delta; squared += delta * delta; max = Math.max(max, delta); }
    }
    changedPixels += Number(changed);
  }
  return { changedPixels, pixelPercent: 100 * changedPixels / (a.length / 4),
    rgbMae: sum / (a.length / 4 * 3), rgbRmse: Math.sqrt(squared / (a.length / 4 * 3)), maxRgbDelta: max };
}
async function save(rgba, recipe, filename) {
  const output = new OffscreenCanvas(recipe.width, recipe.height);
  output.getContext('2d').putImageData(new ImageData(rgba, recipe.width, recipe.height), 0, 0);
  const blob = await output.convertToBlob({ type: 'image/png' });
  const response = await fetch(`/output/${filename}.png`, { method: 'POST', body: blob });
  if (!response.ok) throw new Error(`Cannot save ${filename}`);
}
window.testCase = async ({ recipe, index, browser }) => {
  const backends = recipe.wasmOnly ? ['baseline', 'wasm'] : (index % 2 ? ['js', 'baseline', 'wasm'] : ['wasm', 'baseline', 'js']);
  const workers = {}, result = { id: recipe.id, recipe, backends: {} }, originals = {};
  try {
    let pixels = source.data;
    if (recipe.entropy) {
      pixels = new Uint8ClampedArray(source.data.length);
      let seed = 123456789;
      for (let i = 0; i < pixels.length; i += 4) {
        seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5;
        pixels[i] = seed & 255;
        pixels[i + 1] = (seed >>> 8) & 255;
        pixels[i + 2] = (seed >>> 16) & 255;
        pixels[i + 3] = 255;
      }
    }
    result.inputPixelHash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', pixels))].map(x => x.toString(16).padStart(2, '0')).join('');
    for (const backend of backends) {
      const start = performance.now();
      const worker = new Worker('./worker.mjs', { type: 'module' });
      workers[backend] = worker;
      const buffer = pixels.slice().buffer;
      const setup = await rpc(worker, { action: 'init', backend, buffer, width: source.width, height: source.height }, [buffer]);
      result.backends[backend] = { setup: { ...setup, roundtripMs: performance.now() - start }, uncached: [], repeats: [], changedSettings: [] };
    }
    async function measure(backend, repeat = false) {
      const start = performance.now();
      const response = await rpc(workers[backend], { action: 'process', recipe });
      const returned = performance.now();
      const rgba = expand(response, recipe);
      canvas.width = recipe.width;
      canvas.height = recipe.height;
      canvas.getContext('2d').putImageData(new ImageData(rgba, recipe.width, recipe.height), 0, 0);
      const ended = performance.now();
      const sample = { processingMs: response.processingMs, publicCallMs: response.publicCallMs,
        adapterMs: response.adapterMs, workerRoundtripMs: returned - start,
        expandCanvasMs: ended - returned, e2eMs: ended - start, warnings: response.warnings };
      if (originals[backend]) {
        sample.stability = difference(originals[backend], rgba);
        if (sample.stability.changedPixels) throw new Error(`${backend} output changed on repeat`);
      }
      else {
        originals[backend] = rgba;
        await save(rgba, recipe, `${browser}-${recipe.id}-${backend}`);
      }
      if (repeat) result.backends[backend].repeats.push(sample);
      else result.backends[backend].uncached.push(sample);
    }
    for (let round = 0; round < rounds; round++) {
      for (const backend of round % 2 ? [...backends].reverse() : backends) {
        if (round > 0) await rpc(workers[backend], { action: 'reset' });
        await measure(backend);
      }
      if (round === 0) for (let repeat = 0; repeat < 3; repeat++) {
        for (const backend of repeat % 2 ? [...backends].reverse() : backends) await measure(backend, true);
      }
    }
    if (originals.js) result.difference = difference(originals.wasm, originals.js);
    result.candidateDifference = difference(originals.baseline, originals.wasm);
    if (result.candidateDifference.changedPixels) throw new Error('Candidate differs from baseline');
    for (let variation = 1; variation <= 3; variation++) {
      const changed = { ...recipe, width: recipe.width + variation };
      const outputs = {};
      for (const backend of variation % 2 ? [...backends].reverse() : backends) {
        const start = performance.now();
        const response = await rpc(workers[backend], { action: 'process', recipe: changed });
        const returned = performance.now();
        const rgba = expand(response, changed);
        canvas.width = changed.width;
        canvas.height = changed.height;
        canvas.getContext('2d').putImageData(new ImageData(rgba, changed.width, changed.height), 0, 0);
        const ended = performance.now();
        outputs[backend] = rgba;
        result.backends[backend].changedSettings.push({ width: changed.width, processingMs: response.processingMs,
          publicCallMs: response.publicCallMs, adapterMs: response.adapterMs,
          workerRoundtripMs: returned - start, expandCanvasMs: ended - returned, e2eMs: ended - start });
      }
      if (difference(outputs.baseline, outputs.wasm).changedPixels) throw new Error('Changed-settings candidate differs from baseline');
    }
  } catch (error) {
    result.error = error.message;
  } finally {
    for (const worker of Object.values(workers)) worker.terminate();
  }
  return result;
};
