import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const json = async file => JSON.parse(await readFile(file, 'utf8'));
const median = values => {
  const sorted = [...values].sort((a, b) => a - b);
  const half = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[half] : (sorted[half - 1] + sorted[half]) / 2;
};
const summary = { native: {}, browsers: {} };
for (const name of ['selection', 'spec', 'repeat']) {
  const directory = path.join(root, `native-${name}-results`);
  const report = await json(path.join(directory, 'report.json'));
  const files = (await readdir(directory)).filter(file => file.endsWith('.result.json'));
  const raw = await Promise.all(files.map(file => json(path.join(directory, file))));
  assert.equal(raw.length, report.cases.length * 4);
  for (const worker of raw) {
    assert.equal(worker.max_live_benchmark_processes, 1);
    assert.equal(worker.iterations_per_sample, 1);
    assert.equal(worker.build.dirty, false);
    assert.equal(worker.build.revision, worker.role === 'candidate'
      ? '60b47c264af16842894352ee0fecd00e65594356'
      : '7a57caa5b0be886146322bb6caa9165bad5e0c81');
    assert.ok(worker.sample_ns.length >= 5);
  }
  const events = (await readFile(path.join(directory, 'events.jsonl'), 'utf8')).trim().split('\n').map(JSON.parse);
  let active = null;
  let reaped = 0;
  for (const event of events) {
    if (event.state === 'starting') assert.equal(active, null);
    else if (event.state === 'started') {
      assert.equal(active, null);
      active = event.pid;
    } else if (event.state === 'reaped') {
      assert.equal(active, event.pid);
      active = null;
      reaped++;
    } else throw new Error(`Unexpected event ${event.state}`);
  }
  assert.equal(active, null);
  assert.equal(reaped, raw.length);
  for (const c of report.cases) {
    assert.ok(c.verification.every(v => v.status === 'exact'));
    for (const role of ['accepted', 'candidate']) {
      const samples = raw.filter(r => r.case_name === c.case_name && r.role === role).flatMap(r => r.sample_ns);
      assert.equal(median(samples), c[`${role}_median_ns`]);
    }
    for (let pair = 0; pair < 2; pair++) {
      const sample = role => raw.find(r => r.case_name === c.case_name && r.role === role && r.pair === pair).sample_ns;
      assert.equal(median(sample('candidate')) / median(sample('accepted')), c.pair_ratios[pair]);
    }
  }
  summary.native[name] = { gate: report.gate, workers: raw.length, samples: raw.reduce((n, r) => n + r.sample_ns.length, 0),
    cases: report.cases.map(c => ({ name: c.case_name, gate: c.gate, acceptedNs: c.accepted_median_ns,
      candidateNs: c.candidate_median_ns, ratio: c.median_ratio, pairs: c.pair_ratios })) };
}
for (const name of ['cold-sha-01', 'cold-combined-01']) {
  const report = await json(path.join(root, '../celeste', name, 'results.json'));
  let calls = 0;
  const rows = [];
  for (const [engine, data] of Object.entries(report.browsers)) {
    assert.deepEqual(data.errors, []);
    for (const c of data.results) {
      assert.equal(c.error, undefined);
      assert.equal(c.candidateDifference.changedPixels, 0);
      const row = { engine, recipe: c.id, backends: {} };
      for (const [backend, data] of Object.entries(c.backends)) {
        row.backends[backend] = {};
        for (const mode of ['uncached', 'repeats', 'changedSettings']) {
          assert.equal(data[mode].length, 3);
          calls += data[mode].length;
          for (const sample of data[mode]) if (sample.stability) assert.equal(sample.stability.changedPixels, 0);
          row.backends[backend][mode] = median(data[mode].map(s => s.e2eMs));
        }
      }
      rows.push(row);
    }
  }
  summary.browsers[name] = { calls, rows };
}
console.log(JSON.stringify(summary, null, 2));
