import { mkdir, readFile, writeFile, readdir, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const destination = path.join(root, 'compact/benchmark-results');
const native = path.join(destination, 'cold-processing');
await mkdir(native, { recursive: true });
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
for (const name of ['selection', 'spec', 'repeat']) {
  const source = path.join(root, `native-${name}-results`);
  const output = path.join(native, `native-${name}-results`);
  await mkdir(output);
  for (const file of await readdir(source)) {
    if (['events.jsonl', 'report.json'].includes(file)) await copyFile(path.join(source, file), path.join(output, file));
    if (!file.endsWith('.result.json')) continue;
    const bytes = await readFile(path.join(source, file));
    const { reference, output: pixels, ...record } = JSON.parse(bytes);
    await writeFile(path.join(output, file), JSON.stringify({ ...record, rawResultSha256: digest(bytes) }));
  }
}
for (const file of await readdir(root)) {
  if (file.endsWith('.log') || ['audit.mjs', 'audit.json', 'compact-evidence.mjs'].includes(file)) {
    await copyFile(path.join(root, file), path.join(native, file));
  }
}
for (const role of ['native-baseline', 'native-final']) {
  await mkdir(path.join(native, role));
  await copyFile(path.join(root, role, 'build-provenance.json'), path.join(native, role, 'build-provenance.json'));
}
const browser = path.join(destination, 'celeste');
await mkdir(browser);
for (const name of ['cold-sha-01', 'cold-combined-01']) {
  await mkdir(path.join(browser, name));
  for (const file of ['manifest.json', 'results.json']) await copyFile(path.join(root, '../celeste', name, file), path.join(browser, name, file));
}
for (const file of ['run.mjs', 'page.mjs', 'worker.mjs', 'cases.mjs', 'prepare.mjs', 'adapter.js', 'palette.js', 'baseline-adapter.js']) {
  await copyFile(path.join(root, '../celeste', file), path.join(browser, file));
}
