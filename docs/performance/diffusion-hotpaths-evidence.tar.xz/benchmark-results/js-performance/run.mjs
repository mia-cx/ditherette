import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import os from 'node:os';
import { chromium, firefox, webkit } from 'playwright';
import { runBrowserTransport } from '../../scripts/benchmark-transport.mjs';
import { cases, rounds, callTimeoutMs } from './cases.mjs';

const directory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(directory, '../..');
const candidatePackage = path.resolve(process.env.CELESTE_CANDIDATE ?? path.join(root, 'packages/ditherette/dist'));
const source = '/home/mia/.t3/userdata/attachments/cbe157d0-7266-439e-8d9e-b13ca13a869b-04df8e44-adaf-407f-a750-5867a37ba1b5.png';
const trial = process.argv[2] ?? 'trial01';
if (!/^[a-z0-9-]+$/.test(trial)) throw new Error('Invalid trial name');
const output = path.join(directory, trial);
await mkdir(output);
await mkdir(path.join(output, 'images'));
const engines = { chromium, firefox, webkit };
const selectedCases = process.env.CELESTE_CASES
  ? cases.filter(c => process.env.CELESTE_CASES.split(',').includes(c.id))
  : cases;
const selectedEngines = process.argv[3] ? [process.argv[3]] : trial.startsWith('probe') ? ['chromium'] : Object.keys(engines);
const firefoxPath = process.env.CELESTE_FIREFOX_EXECUTABLE;
const protocol = process.env.CELESTE_PROTOCOL ?? 'screen';
if (!['screen', 'qualify'].includes(protocol)) throw new Error('Invalid measurement protocol');
const sampleRounds = protocol === 'qualify' ? 6 : rounds;
if (selectedEngines.includes('firefox')) {
  if (!firefoxPath) throw new Error('Use the prepared optimizing Firefox runtime');
  const runtime = execFileSync('unzip', ['-p', path.join(path.dirname(firefoxPath), 'omni.ja'), 'chrome/juggler/content/content/Runtime.js'], {encoding:'utf8'});
  if (!runtime.includes('this._debugger.allowUnobservedWasm = true;')) throw new Error('Firefox would measure baseline-only Wasm');
}
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
async function packageHashes(directory) {
  const files = (await readdir(directory, { recursive: true })).filter(file => /\.(js|wasm)$/.test(file)).sort();
  return Object.fromEntries(await Promise.all(files.map(async file => [file, hash(await readFile(path.join(directory, file)))])));
}
const report = { started: new Date().toISOString(), sourceRevision: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  candidateRevision: process.env.CELESTE_CANDIDATE_REVISION ?? execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  sourceDiff: execFileSync('git', ['diff'], { cwd: root, encoding: 'utf8' }),
  input: { path: source, sha256: hash(await readFile(source)) },
  candidatePackage,
  scalarWasmSha256: hash(await readFile(path.join(candidatePackage, 'wasm/scalar/ditherette_wasm_bg.wasm'))),
  backends: ['wasm', 'js'], firefoxPath,
  javascriptRevision: 'a895267baea624a6e89bfcef6c5147f170e8a8f7',
  packageFiles: { candidate: await packageHashes(candidatePackage), javascript: await packageHashes(path.join(directory, 'typescript')) },
  scripts: Object.fromEntries(await Promise.all(['run.mjs', 'page.mjs', 'worker.mjs', 'cases.mjs', 'adapter.js', 'palette.js'].map(async file => [file, hash(await readFile(path.join(directory, file)))]))),
  modes: { uncached: 'First processing call on a fresh processor; module loading and creation excluded. First sample also has fresh worker/JIT state.', warm: 'Fresh processor primed at width+1/+2/+3 outside timer, then recompute exact target width', settingsWarm: 'Same dimensions with rotated palette prime; recompute original palette with source/resize reuse', repeats: 'One identical request after first call; Wasm may return cached output' },
  targetRatio: 0.8, screeningOnly: protocol === 'screen', protocol,
  coldWorkerPolicy: protocol === 'qualify' ? 'New worker before every cold sample; browser/module compilation cache may persist' : 'One worker per backend per recipe',
  host: { cpu: os.cpus()[0].model, logicalCpus: os.cpus().length, platform: os.platform(), release: os.release(), node: process.version, loadBefore: os.loadavg() },
  rounds: sampleRounds, callTimeoutMs, totalTimeoutMs: 25 * 60_000, cases: selectedCases, browsers: {} };
if (protocol === 'qualify') {
  report.modes.uncached = 'First processing call in a new worker and processor for every sample; imports/creation excluded and recorded separately';
  report.modes.warm = 'Fresh processor primed at width+1 through width+6 outside timer, then recompute exact target width';
}
await writeFile(path.join(output, 'manifest.json'), JSON.stringify(report, null, 2));
process.env.DITHERETTE_BENCH_TRANSPORT = '1';
const deadline = Date.now() + report.totalTimeoutMs;

async function startServer() {
  const instance = createServer(async (req, res) => {
    try {
      const pathname = new URL(req.url, 'http://localhost').pathname;
      if (req.method === 'POST' && /^\/output\/[a-z0-9-]+\.png$/.test(pathname)) {
        const chunks = [];
        let size = 0;
        for await (const chunk of req) { size += chunk.length; if (size > 50 * 1024 ** 2) throw new Error('Oversized PNG'); chunks.push(chunk); }
        await writeFile(path.join(output, 'images', path.basename(pathname)), Buffer.concat(chunks));
        res.writeHead(204).end(); return;
      }
      if (req.method !== 'GET') { res.writeHead(405).end(); return; }
      res.setHeader('Cache-Control', 'no-store');
      if (pathname === '/') {
        res.setHeader('Content-Type', 'text/html');
        res.end('<!doctype html><title>Celeste scalar E2E</title><canvas></canvas><script type="module" src="/page.mjs"></script>'); return;
      }
      let filename;
      if (pathname === '/celeste.png') filename = source;
      else if (pathname.startsWith('/dist/')) filename = path.join(candidatePackage, pathname.slice('/dist/'.length));
      else filename = path.join(directory, pathname);
      if (filename !== source && !filename.startsWith(directory + '/') && !filename.startsWith(candidatePackage + '/')) throw new Error('Invalid asset path');
      const extension = path.extname(filename);
      res.setHeader('Content-Type', extension === '.wasm' ? 'application/wasm' : extension === '.png' ? 'image/png' : 'text/javascript');
      const stream = createReadStream(filename);
      stream.on('error', () => { res.statusCode = 404; res.end(); });
      stream.pipe(res);
    } catch (error) { res.writeHead(500).end(String(error)); }
  });
  await new Promise(resolve => instance.listen(0, '127.0.0.1', resolve));
  return { instance, url: `http://127.0.0.1:${instance.address().port}` };
}
for (const name of selectedEngines) {
  await runBrowserTransport({
    startServer,
    launchBrowserServer: () => engines[name].launchServer({ headless: true,
      ...(name === 'firefox' ? { executablePath: path.resolve(firefoxPath) } : {}),
      ...(name === 'webkit' ? { executablePath: path.join(directory, 'webkit-libs/webkit') } : {}) }),
    run: async ({ server, browserServer }) => {
      const browser = await engines[name].connect(browserServer.wsEndpoint());
      try {
        const context = await browser.newContext({ viewport: { width: 1400, height: 1000 } });
        const page = await context.newPage();
        const errors = [];
        page.on('pageerror', error => errors.push(error.message));
        await page.goto(server.url);
        await page.waitForFunction(() => typeof window.testCase === 'function');
        const entry = { version: browser.version(), source: await page.evaluate(() => window.loadSource()), errors, results: [] };
        report.browsers[name] = entry;
        for (const [index, recipe] of selectedCases.entries()) {
          if (Date.now() >= deadline) { entry.stopped = 'Predeclared total wall-time cap'; break; }
          entry.results.push(await page.evaluate(args => window.testCase(args), { recipe, index, browser: name, protocol, sampleRounds }));
          await writeFile(path.join(output, 'results.json'), JSON.stringify(report, null, 2));
        }
        await context.close();
      } finally { await browser.close(); }
    }
  });
}
report.finished = new Date().toISOString();
report.host.loadAfter = os.loadavg();
await writeFile(path.join(output, 'results.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify({ output, completed: Object.fromEntries(Object.entries(report.browsers).map(([name, data]) => [name, { cases: data.results.length, errors: data.results.filter(r => r.error).map(r => ({ id: r.id, error: r.error })) }])) }));
