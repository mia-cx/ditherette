import { WPLACE_PALETTE } from './palette.js';

const palette = WPLACE_PALETTE.map(c => ({ ...c, enabled: true }));
let source, backend, api, adapter, resizeImageData, quantizeImage, processor;
async function reset() {
  processor?.dispose();
  const start = performance.now();
  if (backend !== 'js') processor = await api.createDitherette({ threads: 'disabled' });
  return performance.now() - start;
}
function settingsFor(c) {
  return {
    output: { width: c.width, height: c.height, lockAspect: true, resize: c.resize,
      alphaMode: c.alphaMode ?? 'preserve', alphaThreshold: c.alphaThreshold ?? 128, matteKey: c.matteKey ?? '#000000', autoSizeOnUpload: false, scaleFactor: 1 },
    colorSpace: c.colorSpace,
    dither: { algorithm: c.algorithm, strength: c.strength ?? 75, placement: c.adaptive ? 'adaptive' : 'everywhere',
      placementRadius: c.placementRadius ?? 1, placementThreshold: c.placementThreshold ?? 0.1, placementSoftness: c.placementSoftness ?? 0.1, serpentine: c.serpentine ?? true,
      seed: c.seed ?? 123456789, useColorSpace: c.vector ?? false }
  };
}
self.onmessage = async ({ data: message }) => {
  try {
    if (message.action === 'init') {
      backend = message.backend;
      source = new ImageData(new Uint8ClampedArray(message.buffer), message.width, message.height);
      const start = performance.now();
      if (backend !== 'js') {
        api = await import('/dist/index.js');
        adapter = await import('./adapter.js');
      } else {
        ({ resizeImageData } = await import('/typescript/src/lib/processing/resize.js'));
        ({ quantizeImage } = await import('/typescript/src/lib/processing/quantize.js'));
      }
      const importMs = performance.now() - start;
      self.postMessage({ importMs, initMs: await reset() });
      return;
    }
    if (message.action === 'reset') {
      self.postMessage({ initMs: await reset() });
      return;
    }
    const c = message.recipe;
    const settings = settingsFor(c);
    const selectedPalette = c.paletteShift ? [...palette.slice(1), palette[0]] : palette;
    let result, paletteBytes, adapterMs = 0;
    const started = performance.now();
    let publicStarted = started;
    if (backend !== 'js') {
      const { request } = adapter.packageProcessRequest(source, selectedPalette, settings, c);
      if (c.resizeOverride) request.recipe.output.resize = c.resizeOverride;
      if (c.matchingOverride) request.recipe.match = c.matchingOverride;
      if (c.ditherOverride) request.recipe.dither = c.ditherOverride;
      publicStarted = performance.now();
      adapterMs = publicStarted - started;
      result = c.resizeOnly
        ? processor.resize({ version: 1, source: request.source, output: request.recipe.output })
        : processor.process(request);
      if (!c.resizeOnly) paletteBytes = result.palette.rgba;
    } else {
      const resized = resizeImageData(source, c.width, c.height, c.resize);
      result = c.resizeOnly ? { data: new Uint8Array(resized.data.buffer) } : quantizeImage(resized, selectedPalette, settings);
      if (!c.resizeOnly) {
        paletteBytes = new Uint8Array(result.palette.length * 4);
        result.palette.forEach((entry, i) => {
          if (entry.kind !== 'transparent') paletteBytes.set([entry.rgb.r, entry.rgb.g, entry.rgb.b, 255], i * 4);
        });
      }
    }
    const ended = performance.now();
    let pixels = c.resizeOnly ? result.data : result.indices;
    const borrowedOutput = pixels.buffer === source.data.buffer;
    // Transfer ownership after timing either backend's identity alias.
    if (borrowedOutput) pixels = pixels.slice();
    const response = { buffer: pixels.buffer, palette: paletteBytes, adapterMs,
      processingMs: ended - started, publicCallMs: ended - publicStarted, borrowedOutput,
      warnings: result.warnings ?? [] };
    self.postMessage(response, [pixels.buffer]);
  } catch (error) {
    self.postMessage({ error: `${error.name}: ${error.message}`, stack: error.stack });
  }
};
