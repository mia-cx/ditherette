import { readFileSync } from 'node:fs';

const [filename] = process.argv.slice(2);
if (!filename) throw new Error('Usage: summarize.mjs RESULTS_JSON');
const report = JSON.parse(readFileSync(filename, 'utf8'));
const median = values => {
  const sorted = values.toSorted((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
};
const number = value => Number.isFinite(value) ? value.toFixed(2) : 'n/a';
console.log('| Browser | Recipe | State | Wasm ms | JS ms | Wasm/JS | Result |');
console.log('|---|---|---|---:|---:|---:|---|');
let failures = 0;
for (const [browser, data] of Object.entries(report.browsers)) {
  for (const item of data.results) {
    if (item.error) {
      console.log(`| ${browser} | ${item.id} | error | | | | ${item.error} |`);
      failures++;
      continue;
    }
    for (const state of ['uncached', 'warm', 'settingsWarm', 'repeats']) {
      const wasmSamples = item.backends.wasm[state];
      const jsSamples = item.backends.js[state];
      if (!wasmSamples.length || !jsSamples.length) continue;
      const wasm = median(wasmSamples.map(sample => sample.publicCallMs));
      const js = median(jsSamples.map(sample => sample.publicCallMs));
      const noOp = wasmSamples.every(sample => sample.borrowedOutput) && jsSamples.every(sample => sample.borrowedOutput);
      const ratio = js > 0 ? wasm / js : NaN;
      const status = noOp ? 'borrowed no-op' : ratio <= report.targetRatio ? 'target met' : 'target missed';
      if (status === 'target missed' && state !== 'repeats') failures++;
      console.log(`| ${browser} | ${item.id} | ${state} | ${number(wasm)} | ${number(js)} | ${number(ratio)} | ${status} |`);
    }
  }
  if (data.stopped || data.results.length !== report.cases.length) failures++;
}
console.log(`\n${report.screeningOnly ? 'Screening only.' : 'Six-sample comparison.'} ${failures} unmet cells or execution failures.`);
process.exitCode = failures ? 2 : 0;
