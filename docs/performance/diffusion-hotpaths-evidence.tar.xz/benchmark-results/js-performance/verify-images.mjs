import { readdirSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';

const [accepted, candidate] = process.argv.slice(2);
if (!accepted || !candidate) throw new Error('Usage: verify-images.mjs ACCEPTED_TRIAL CANDIDATE_TRIAL');
const names = readdirSync(path.join(candidate, 'images')).filter(name => name.endsWith('-wasm.png')).sort();
if (!names.length) throw new Error('Candidate has no Wasm images');
const evidence = names.map(name => {
  const before = readFileSync(path.join(accepted, 'images', name));
  const after = readFileSync(path.join(candidate, 'images', name));
  return { name, exactPngBytes: before.equals(after), sha256: createHash('sha256').update(after).digest('hex') };
});
console.log(JSON.stringify({ accepted, candidate, images: evidence }, null, 2));
process.exitCode = evidence.every(image => image.exactPngBytes) ? 0 : 2;
