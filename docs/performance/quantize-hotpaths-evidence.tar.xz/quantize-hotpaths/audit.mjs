import assert from 'node:assert/strict';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.dirname(fileURLToPath(import.meta.url));
const json = async file => JSON.parse(await readFile(file, 'utf8'));
const median = values => values.toSorted((a, b) => a - b)[Math.floor(values.length / 2)];
const summary = { native: {}, browsers: {}, timedCalls: 0, primes: 0, exactRepeats: 0, exactPngPairs: 0 };
for (const name of ['alpha-native-results', 'srgb-repeat-results', 'spec-results']) {
  const dir = path.join(root, name);
  const report = await json(path.join(dir, 'report.json'));
  const workers = await Promise.all((await readdir(dir)).filter(f => f.endsWith('.result.json')).map(f => json(path.join(dir, f))));
  for (const worker of workers) {
    assert.equal(worker.max_live_benchmark_processes, 1);
    assert.equal(worker.build.dirty, false);
    assert.ok(worker.sample_ns.length >= 5);
  }
  assert.ok(report.cases.every(c => c.verification.every(v => v.status === 'exact')));
  summary.native[name] = { gate: report.gate, workers: workers.length, samples: workers.reduce((n, w) => n + w.sample_ns.length, 0),
    cases: report.cases.map(c => ({ name: c.case_name, gate: c.gate, ratio: c.median_ratio, pairs: c.pair_ratios })) };
}
const browserRoot = path.join(root, '../quantize-hotpaths-browser');
const trials = ['baseline-a', 'alpha-a', 'inline-b', 'alpha-b', 'last-c', 'alpha-c', 'final-alpha', 'final-baseline'];
for (const trial of trials) {
  const report = await json(path.join(browserRoot, trial, 'results.json'));
  assert.ok(report.finished);
  summary.browsers[trial] = {};
  for (const [name, browser] of Object.entries(report.browsers)) {
    assert.deepEqual(browser.errors, []);
    assert.equal(browser.version, { chromium: '147.0.7727.15', firefox: '148.0.2', webkit: '26.4' }[name]);
    summary.browsers[trial][name] = browser.results.map(result => {
      assert.ok(!result.error);
      const backends = {};
      for (const [backend, data] of Object.entries(result.backends)) {
        summary.primes += data.untimedPrimes;
        backends[backend] = {};
        for (const mode of ['uncached', 'warm', 'repeats']) {
          const samples = data[mode];
          summary.timedCalls += samples.length;
          for (const sample of samples) if (sample.stability) {
            assert.equal(sample.stability.changedPixels, 0);
            summary.exactRepeats++;
          }
          backends[backend][mode] = { publicMs: median(samples.map(s => s.publicCallMs)), e2eMs: median(samples.map(s => s.e2eMs)) };
        }
      }
      return { id: result.id, backends };
    });
  }
}
for (const trial of trials.filter(t => !t.includes('baseline'))) {
  const control = trial === 'final-alpha' ? 'final-baseline' : 'baseline-a';
  const controls = await readdir(path.join(browserRoot, control, 'images'));
  for (const file of (await readdir(path.join(browserRoot, trial, 'images'))).filter(f => f.endsWith('-wasm.png') && controls.includes(f))) {
    assert.deepEqual(await readFile(path.join(browserRoot, trial, 'images', file)), await readFile(path.join(browserRoot, control, 'images', file)));
    summary.exactPngPairs++;
  }
}
await writeFile(path.join(root, 'audit.json'), JSON.stringify(summary, null, 2));
console.log(JSON.stringify({ timedCalls: summary.timedCalls, primes: summary.primes, exactRepeats: summary.exactRepeats, exactPngPairs: summary.exactPngPairs,
  native: Object.fromEntries(Object.entries(summary.native).map(([k, v]) => [k, { workers: v.workers, samples: v.samples, gate: v.gate }])) }));
